import csv

# Simulated evaluation results
results = [
    {"Prompt": "Hello", "Response": "Hi there!", "Score": 9},
    {"Prompt": "Tell me a joke", "Response": "Why did the AI cross the road? To optimize the chicken's path.", "Score": 8}
]

with open("results.csv", "w", newline="") as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=["Prompt", "Response", "Score"])
    writer.writeheader()
    writer.writerows(results)

print("LLM Evaluation complete. Results saved to results.csv.")
