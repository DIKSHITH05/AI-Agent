# Placeholder environment for RL agent.
