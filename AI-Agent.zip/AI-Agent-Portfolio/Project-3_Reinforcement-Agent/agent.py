import random

actions = ["up", "down", "left", "right"]
q_table = {}

# Simulated Q-learning process
for episode in range(10):
    state = (0, 0)
    for step in range(5):
        action = random.choice(actions)
        reward = random.randint(-1, 1)
        q_table[(state, action)] = reward
        print(f"Episode {episode+1}, State: {state}, Action: {action}, Reward: {reward}")
print("Training Complete.")
