import nltk
from transformers import pipeline

# Load pre-trained model
chatbot = pipeline("conversational", model="microsoft/DialoGPT-medium")

print("AI Chatbot Ready! Type 'quit' to exit.")
while True:
    user_input = input("You: ")
    if user_input.lower() == 'quit':
        break
    response = chatbot(user_input)
    print("Bot:", response[0]['generated_text'])
